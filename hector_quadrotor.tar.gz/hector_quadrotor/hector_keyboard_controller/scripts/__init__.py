"""
Holds the different controllers for hector_quadrotor
"""