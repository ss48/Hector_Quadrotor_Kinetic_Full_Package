# hector_keyboard_teleop
This file is a Teleop code facilitating control of the hector quadrotor from keyboard. 
The following functions are made available as of now and more shall be updated soon.

w - Forward,
a - Left,
s - Reverse,
d - Right,
z - Climb up,
c - Climb down,
. - Stop
