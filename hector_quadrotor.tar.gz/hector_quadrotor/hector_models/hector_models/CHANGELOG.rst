^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package hector_models
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.4.2 (2016-06-24)
------------------

0.4.1 (2015-11-08)
------------------

0.4.0 (2015-11-07)
------------------

0.3.2 (2014-09-01)
------------------

0.3.1 (2014-03-30)
------------------
* made hector_models a true metapackage
* Moved package hector_sensors_gazebo to ../hector_gazebo
* Contributors: Johannes Meyer

0.3.0 (2013-09-02)
------------------
* catkinized stack hector_models
