^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package hector_gazebo_worlds
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.5.0 (2016-06-24)
------------------

0.4.1 (2016-06-24)
------------------

0.4.0 (2015-11-07)
------------------

0.3.8 (2016-06-24)
------------------

0.3.7 (2015-11-07)
------------------

0.3.6 (2015-03-21)
------------------

0.3.5 (2015-02-23)
------------------
* Change drc qual 4 settings to be same as current Atlas default
* Add drc final qual step block world and launch file
* - Adjusted lighting
* - Update world
* -Add inner block with stations model
* -Add complete sick robot day 2014 outer ring with stations
* -Add two target panel examples to world
* -Update world file
* -Add complete sick robot day 2014 target stations
* -Add inner block to world
* -Add inner block for sick robot day 2014
* -Add target model to sick robot day 2014 world
* -Add sick robot day target model
* Contributors: Stefan Kohlbrecher

0.3.4 (2014-09-01)
------------------
* updated world files to SDF 1.4 using gzsdf
* Change light for sick robot day 2014 world, add number panel example
* Add sick robot number panel stl file for collision geom
* Add collada files for sick robot day number panels
* Add sick robot day number panels
* Add sick robot day 2014 related files
* Add model for sick robot day 2014 ring
* added args roslaunch argument to pass additional command line arguments to gzserver
* Contributors: Johannes Meyer, Stefan Kohlbrecher

0.3.3 (2014-05-27)
------------------

0.3.2 (2014-03-30)
------------------
* added missing install rule
* Contributors: Johannes Meyer

0.3.1 (2013-09-23)
------------------

0.3.0 (2013-09-02)
------------------
* Catkinization of stack hector_gazebo
