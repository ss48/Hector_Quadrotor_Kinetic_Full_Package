^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rtt_hector_pose_estimation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.0 (2015-02-22)
------------------

0.1.5 (2014-10-02)
------------------

0.1.3 (2014-07-09)
------------------
* 0.1.3
* rtt_hector_pose_estimation: added missing rtt_std_msgs dependency
* rtt_hector_pose_estimation: updated CMakeLists.txt for Orocos Toolchain 2.7
* Contributors: Johannes Meyer

0.1.2 (2014-06-02)
------------------

0.1.1 (2014-03-30)
------------------
* added CATKIN_IGNORE marker to prevent rosdep errors on missing dependency rtt_nav_msgs
* hector_pose_estimation/rtt_hector_pose_estimation: removed optional usage of package hector_uav_msgs and created a separate package hector_quadrotor_pose_estimation instead
* added rtt_ros/plugin_depend tags to package.xml and removed rtt stuff from CATKIN_DEPENDS
* Contributors: Johannes Meyer
