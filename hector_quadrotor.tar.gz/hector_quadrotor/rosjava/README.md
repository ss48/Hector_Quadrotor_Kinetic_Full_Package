RosJava
=======

Metapackage for the official rosjava repositories.

See the [rosjava_core](https://github.com/rosjava/rosjava_core) readme for more details.
